const $=id=>document.getElementById(id);
function toggleMenu(){document.getElementById("navLinks").classList.toggle("open")}
function makeScript(){
 const t=$("topic").value.trim()||"एक cinematic गांव की कहानी";
 $("scriptOut").textContent=`0–5s: ${t} का cinematic establishing shot.\n5–10s: मुख्य character का action और hook.\n10–15s: अचानक छोटा twist — viewer की curiosity बढ़े.\n15–20s: memorable ending + “ऐसी videos के लिए follow करें।”`;
}
function makeCaptions(){
 const t=$("captionTopic").value.trim()||"मेरी नई Reel";
 $("captionOut").textContent=`1. ${t} 🎬 कहानी अभी शुरू हुई है...\n2. इस पल को miss मत करना ✨\n3. अगर आपको ऐसी videos पसंद हैं तो follow करें ❤️\n4. अगली Reel में मिलते हैं 🔥`;
}
function makeIdeas(){
 const n=$("niche").value.trim()||"AI Creator";
 $("ideasOut").textContent=`• ${n}: 3 beginner mistakes\n• ${n}: एक viral-style short idea\n• ${n}: before/after transformation\n• ${n}: 20-second tutorial\n• ${n}: “क्या आप जानते हैं?” series`;
}
async function copyText(btn){
 const text=btn.parentElement.querySelector("p").textContent;
 try{await navigator.clipboard.writeText(text);btn.textContent="Copied ✓";setTimeout(()=>btn.textContent="Copy Prompt",1200)}
 catch(e){alert("Copy नहीं हुआ; prompt को manually select करें।")}
}
$("year").textContent=new Date().getFullYear();