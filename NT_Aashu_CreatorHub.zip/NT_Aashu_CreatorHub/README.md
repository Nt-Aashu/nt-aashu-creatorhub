# NT Aashu CreatorHub

यह एक static, mobile-friendly creator website है।

## चलाने का तरीका
1. `index.html`, `style.css` और `script.js` को एक ही folder में रखें।
2. `index.html` को browser में खोलें।
3. Contact section में अपना email बदलें।

## Online publish
किसी static hosting service पर ये तीन files upload करके site publish की जा सकती है।

## कमाई जोड़ना
Traffic और eligibility बनने के बाद आप legitimate advertising, affiliate programs या अपने digital products जोड़ सकते हैं। किसी भी ad/affiliate platform की terms और applicable laws follow करें।

## अगला upgrade
- Real AI API integration
- Login/Admin panel
- Database
- Paid prompt packs
- Analytics
- Ad/affiliate management
